"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function AuthForm({ type = "login" }) {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const isSignup = type === "signup";

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!form.email || !form.password || (isSignup && !form.name)) {
      alert("Please fill in all required fields.");
      return;
    }

    setLoading(true);

    // Simulate database lookup/creation
    setTimeout(() => {
      const displayName = isSignup ? form.name : form.email.split("@")[0].replace(/[._]/g, " ");
      const loggedUser = {
        name: displayName.charAt(0).toUpperCase() + displayName.slice(1),
        email: form.email,
      };

      localStorage.setItem("user", JSON.stringify(loggedUser));
      setLoading(false);
      
      // Navigate to dashboard and force navigation reload
      router.push("/dashboard");
      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 100);
    }, 800);
  };

  return (
    <main className="relative min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center overflow-hidden px-6 py-12">
      {/* Decorative blurred background blobs */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-indigo-500/10 blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-96 h-96 rounded-full bg-purple-500/10 blur-[100px] pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-teal-500/5 blur-[150px] pointer-events-none"></div>

      <div className="relative w-full max-w-5xl rounded-[2.5rem] border border-white/10 bg-slate-900/40 backdrop-blur-xl shadow-[0_0_50px_-12px_rgba(79,70,229,0.3)] grid lg:grid-cols-12 overflow-hidden z-10">
        
        {/* Left Side - Brand Showcase (Hidden on Mobile) */}
        <div className="lg:col-span-5 bg-gradient-to-b from-indigo-950/40 to-slate-950/80 p-10 border-r border-white/5 flex flex-col justify-between text-slate-200 hidden lg:flex">
          <div>
            <Link href="/" className="inline-flex items-center gap-3 hover:opacity-90 transition">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-600 text-xl text-white shadow-lg shadow-indigo-500/30">
                ⚡
              </span>
              <span className="text-xl font-black tracking-tight text-white">PlanWise AI</span>
            </Link>
            
            <div className="mt-20 space-y-6">
              <h1 className="text-4xl font-extrabold tracking-tight leading-tight text-white">
                Turn plan complexity into execution clarity.
              </h1>
              <p className="text-base text-slate-400 leading-relaxed">
                Unlock automated risk detection, workload balancing, and multi-agent plan refinements with our state-of-the-art AI planner.
              </p>
            </div>
          </div>

          <div className="border-t border-white/5 pt-6 mt-12">
            <div className="flex items-center gap-3">
              <div className="flex -space-x-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold ring-2 ring-slate-900">A</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-600 text-xs font-bold ring-2 ring-slate-900">K</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-xs font-bold ring-2 ring-slate-900">M</span>
              </div>
              <span className="text-xs font-medium text-slate-400">
                Trusted by 15,000+ project leaders globally.
              </span>
            </div>
          </div>
        </div>

        {/* Right Side - Active Auth Form */}
        <div className="lg:col-span-7 p-8 md:p-12 flex flex-col justify-center">
          <div>
            <Link 
              href="/" 
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <span>←</span> Back to Home
            </Link>
            
            <h2 className="mt-8 text-3xl md:text-4xl font-black tracking-tight text-white">
              {isSignup ? "Create your account" : "Welcome back"}
            </h2>
            <p className="mt-2 text-sm text-slate-400">
              {isSignup 
                ? "Start planning your projects visually and logically with AI." 
                : "Log in to resume where you left off."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            {isSignup && (
              <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-300">Name</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">👤</span>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full rounded-2xl border border-white/10 bg-slate-900/60 pl-11 pr-5 py-4 text-sm text-white placeholder-slate-500 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                    placeholder="Abdul Ghani"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-sm font-bold text-slate-300">Email Address</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">✉️</span>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full rounded-2xl border border-white/10 bg-slate-900/60 pl-11 pr-5 py-4 text-sm text-white placeholder-slate-500 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="block text-sm font-bold text-slate-300">Password</label>
                {!isSignup && (
                  <a href="#" className="text-xs text-indigo-400 hover:underline">Forgot password?</a>
                )}
              </div>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">🔒</span>
                <input
                  type="password"
                  required
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full rounded-2xl border border-white/10 bg-slate-900/60 pl-11 pr-5 py-4 text-sm text-white placeholder-slate-500 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full relative mt-2 overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-4 text-sm font-bold text-white hover:from-indigo-500 hover:to-purple-500 transition-all duration-300 shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/35 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                  Please wait...
                </>
              ) : (
                <>
                  {isSignup ? "Create Account" : "Sign In"} ⚡
                </>
              )}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-slate-400">
            {isSignup ? "Already have an account?" : "Don't have an account?"}{" "}
            <Link 
              href={isSignup ? "/login" : "/signup"} 
              className="font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              {isSignup ? "Sign In" : "Create one now"}
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
