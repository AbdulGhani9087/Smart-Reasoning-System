export default function PlanResult({ plan, onReset }) {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 rounded-[2rem] border border-indigo-100 bg-white p-6 card-shadow md:flex-row md:items-center dark:border-gray-800/85 dark:bg-gray-900 transition-all">
        <div>
          <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400">AI Generated Blueprint</p>
          <h1 className="mt-2 text-3xl font-black text-gray-950 dark:text-white">{plan.goal}</h1>
        </div>
        <button
          onClick={onReset}
          className="rounded-2xl border border-indigo-200 px-5 py-3 font-bold text-indigo-700 hover:bg-indigo-50 dark:border-gray-700 dark:text-indigo-400 dark:hover:bg-indigo-950/30 transition cursor-pointer"
        >
          Generate New Plan
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-[2rem] border border-indigo-100 bg-white p-6 card-shadow dark:border-gray-800/85 dark:bg-gray-900 transition-all">
          <h2 className="text-2xl font-black text-gray-950 dark:text-white">Assumptions</h2>
          <ul className="mt-4 space-y-3">
            {plan.assumptions.map((item) => (
              <li key={item} className="rounded-2xl bg-indigo-50 dark:bg-slate-800/60 p-4 text-gray-700 dark:text-slate-200">
                ✅ {item}
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-[2rem] border border-indigo-100 bg-white p-6 card-shadow dark:border-gray-800/85 dark:bg-gray-900 transition-all">
          <h2 className="text-2xl font-black text-gray-950 dark:text-white">Missing Information</h2>
          <ul className="mt-4 space-y-3">
            {plan.missingInfo.map((item) => (
              <li key={item} className="rounded-2xl bg-amber-50/70 dark:bg-amber-950/15 p-4 text-gray-700 dark:text-gray-300 border-l-4 border-amber-500">
                ❓ {item}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="rounded-[2rem] border border-indigo-100 bg-white p-6 card-shadow dark:border-gray-800/85 dark:bg-gray-900 transition-all">
        <h2 className="text-2xl font-black text-gray-950 dark:text-white">Step-by-Step Action Plan</h2>
        <div className="mt-6 space-y-5">
          {plan.steps.map((step, index) => (
            <div key={step.title} className="rounded-3xl border border-indigo-100 dark:border-slate-800/60 bg-indigo-50/50 dark:bg-slate-800/40 p-5">
              <div className="flex gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-indigo-600 font-black text-white">
                  {index + 1}
                </span>
                <div>
                  <h3 className="text-xl font-black text-gray-950 dark:text-white">{step.title}</h3>
                  <p className="mt-2 text-gray-700 dark:text-gray-300"><b>Why:</b> {step.why}</p>
                  <ul className="mt-4 grid gap-2 md:grid-cols-2">
                    {step.tasks.map((task) => (
                      <li key={task} className="rounded-2xl bg-white dark:bg-gray-900 border border-indigo-50/30 dark:border-gray-800 p-3 text-sm font-semibold text-gray-700 dark:text-gray-300">
                        {task}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-[2rem] border border-indigo-100 dark:border-gray-800 bg-gray-950 dark:bg-gray-900/60 p-6 text-white card-shadow transition-all">
        <h2 className="text-2xl font-black">Final Action Plan</h2>
        <ol className="mt-4 space-y-3">
          {plan.finalActionPlan.map((item, index) => (
            <li key={item} className="rounded-2xl bg-white/10 dark:bg-white/5 p-4">
              <span className="font-black text-indigo-200">{index + 1}.</span> {item}
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
